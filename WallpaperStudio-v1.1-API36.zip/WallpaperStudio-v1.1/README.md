# Wallpaper Studio 1.1

Aplicativo Android de wallpapers feito com Kotlin + Jetpack Compose.

## Recursos da V1.0
- Pesquisa
- Categorias
- Favoritos durante a sessão
- Visualização
- Definir como wallpaper
- Modo claro/escuro
- Tela preparada para geração por IA

## Compilar
Abra o projeto em Android Studio ou num ambiente Android que suporte Gradle.
Depois execute:

./gradlew assembleDebug

O APK será criado em:
app/build/outputs/apk/debug/app-debug.apk

## Observação
Os wallpapers de demonstração usam URLs do Unsplash. Para uma versão publicada na Play Store, substitua-os por imagens/licenças e infraestrutura próprias.
A geração de imagens por IA requer uma API/modelo de geração e não está ligada nesta V1.0.


## Atualização 1.1
- compileSdk = 36
- targetSdk = 36
- Android Gradle Plugin 8.9.1
- versionCode = 2
- versionName = 1.1

Esta configuração acompanha o requisito atual do Google Play para novos apps a partir de 31 de agosto de 2026.
