package com.wallpaperstudio.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import java.net.URL

data class Wallpaper(
    val id: Int,
    val title: String,
    val category: String,
    val url: String
)

private val wallpapers = listOf(
    Wallpaper(1, "Mountain Night", "Nature", "https://images.unsplash.com/photo-1500534623283-312aade485b7?w=800"),
    Wallpaper(2, "Sports Car", "Cars", "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800"),
    Wallpaper(3, "City Lights", "Technology", "https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=800"),
    Wallpaper(4, "Space", "Space", "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800"),
    Wallpaper(5, "Ocean", "Nature", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800"),
    Wallpaper(6, "Abstract", "Abstract", "https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=800"),
    Wallpaper(7, "Road", "Cars", "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800"),
    Wallpaper(8, "Galaxy", "Space", "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800")
)

private val categories = listOf("Todos", "Nature", "Cars", "Anime", "Games", "Technology", "Space", "Football", "3D", "Abstract")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WallpaperStudioApp() }
    }
}

@Composable
fun WallpaperStudioApp() {
    var dark by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("Todos") }
    var search by remember { mutableStateOf("") }
    var page by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Wallpaper?>(null) }
    var favorites by remember { mutableStateOf(setOf<Int>()) }

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme() else lightColorScheme()
    ) {
        if (selected != null) {
            DetailScreen(
                wallpaper = selected!!,
                favorite = favorites.contains(selected!!.id),
                onBack = { selected = null },
                onFavorite = {
                    favorites = if (favorites.contains(selected!!.id))
                        favorites - selected!!.id else favorites + selected!!.id
                }
            )
            return@MaterialTheme
        }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = page == 0,
                        onClick = { page = 0 },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Início") }
                    )
                    NavigationBarItem(
                        selected = page == 1,
                        onClick = { page = 1 },
                        icon = { Icon(Icons.Default.Favorite, null) },
                        label = { Text("Favoritos") }
                    )
                    NavigationBarItem(
                        selected = page == 2,
                        onClick = { page = 2 },
                        icon = { Icon(Icons.Default.AutoAwesome, null) },
                        label = { Text("IA") }
                    )
                    NavigationBarItem(
                        selected = page == 3,
                        onClick = { page = 3 },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Definições") }
                    )
                }
            }
        ) { padding ->
            when (page) {
                0 -> HomeScreen(
                    padding = padding,
                    search = search,
                    onSearch = { search = it },
                    category = selectedCategory,
                    onCategory = { selectedCategory = it },
                    onSelect = { selected = it }
                )
                1 -> FavoritesScreen(
                    padding = padding,
                    favorites = wallpapers.filter { favorites.contains(it.id) },
                    onSelect = { selected = it }
                )
                2 -> AiScreen(padding)
                3 -> SettingsScreen(padding, dark, onDark = { dark = it })
            }
        }
    }
}

@Composable
fun HomeScreen(
    padding: PaddingValues,
    search: String,
    onSearch: (String) -> Unit,
    category: String,
    onCategory: (String) -> Unit,
    onSelect: (Wallpaper) -> Unit
) {
    val filtered = wallpapers.filter {
        (category == "Todos" || it.category == category) &&
                (search.isBlank() || it.title.contains(search, true) || it.category.contains(search, true))
    }

    Column(Modifier.padding(padding).padding(horizontal = 14.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Wallpaper Studio", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Descobre o teu próximo wallpaper", color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = search,
            onValueChange = onSearch,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Pesquisar wallpapers...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )

        Spacer(Modifier.height(12.dp))
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories.size) { i ->
                FilterChip(
                    selected = category == categories[i],
                    onClick = { onCategory(categories[i]) },
                    label = { Text(categories[i]) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered) { wallpaper ->
                WallpaperCard(wallpaper, onClick = { onSelect(wallpaper) })
            }
        }
    }
}

@Composable
fun WallpaperCard(wallpaper: Wallpaper, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp)
    ) {
        Image(
            painter = rememberAsyncImagePainter(wallpaper.url),
            contentDescription = wallpaper.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun DetailScreen(
    wallpaper: Wallpaper,
    favorite: Boolean,
    onBack: () -> Unit,
    onFavorite: () -> Unit
) {
    val context = LocalContext.current
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(
            painter = rememberAsyncImagePainter(wallpaper.url),
            contentDescription = wallpaper.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = Color.White)
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    null,
                    tint = Color.White
                )
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = .65f))
                .padding(18.dp)
        ) {
            Text(wallpaper.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(wallpaper.category, color = Color.LightGray)

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = {
                    setWallpaper(context, wallpaper.url)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Wallpaper, null)
                Spacer(Modifier.width(8.dp))
                Text("Definir como wallpaper")
            }
        }
    }
}

fun setWallpaper(context: Context, url: String) {
    Thread {
        try {
            val bitmap: Bitmap = android.graphics.BitmapFactory.decodeStream(URL(url).openStream())
            WallpaperManager.getInstance(context).setBitmap(bitmap)
            (context as? android.app.Activity)?.runOnUiThread {
                Toast.makeText(context, "Wallpaper definido!", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            (context as? android.app.Activity)?.runOnUiThread {
                Toast.makeText(context, "Não foi possível definir o wallpaper.", Toast.LENGTH_SHORT).show()
            }
        }
    }.start()
}

@Composable
fun FavoritesScreen(
    padding: PaddingValues,
    favorites: List<Wallpaper>,
    onSelect: (Wallpaper) -> Unit
) {
    Column(Modifier.padding(padding).padding(14.dp)) {
        Text("Favoritos", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (favorites.isEmpty()) {
            Text("Ainda não tens wallpapers favoritos.")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(favorites) { WallpaperCard(it) { onSelect(it) } }
            }
        }
    }
}

@Composable
fun AiScreen(padding: PaddingValues) {
    var prompt by remember { mutableStateOf("") }
    Column(
        Modifier.padding(padding).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(25.dp))
        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(70.dp))
        Spacer(Modifier.height(15.dp))
        Text("Criar com IA", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(
            "Descreve o wallpaper que queres criar.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth().height(130.dp),
            placeholder = { Text("Ex.: carro futurista azul numa cidade à noite") }
        )
        Spacer(Modifier.height(15.dp))
        Button(
            onClick = {
                // Nesta V1.0 o botão é a interface preparada.
                // A API de geração de imagens será ligada numa próxima versão.
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.AutoAwesome, null)
            Spacer(Modifier.width(8.dp))
            Text("Gerar wallpaper")
        }
    }
}

@Composable
fun SettingsScreen(
    padding: PaddingValues,
    dark: Boolean,
    onDark: (Boolean) -> Unit
) {
    Column(Modifier.padding(padding).padding(20.dp)) {
        Text("Definições", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Modo escuro", fontWeight = FontWeight.SemiBold)
                Text("Alterar aparência do aplicativo")
            }
            Switch(checked = dark, onCheckedChange = onDark)
        }
        Spacer(Modifier.height(20.dp))
        Text("Wallpaper Studio 1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Aplicativo de wallpapers", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
